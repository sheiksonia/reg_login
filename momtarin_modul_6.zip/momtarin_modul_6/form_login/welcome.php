<?php
	if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		$email = $_POST['email'];
		$password = $_POST['password'];

		// Perform validation
		if (empty($email) || empty($password)) {
			echo "<p style='color:red'>Both fields are required and must not be empty</p>";
		} else {
			// Check if login credentials are valid
			// Assume that the credentials are valid if the email address is 'example@mail.com' and the password is 'password'
			if ($email == 'example@mail.com' && $password == 'password') {
				// Redirect to welcome page
				header("Location: welcome.php?name=John"); // Assume the user's first name is John
				exit();
			} else {
				echo "<p style='color:red'>Invalid login </p>";
			}
		}
	}
	?>