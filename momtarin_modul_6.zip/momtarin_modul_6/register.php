f<?php
  // check if the form has been submitted
  if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // get the form data
    $first_name = $_POST['first-name'];
    $last_name = $_POST['last-name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm-password'];
    
    // check if all fields are filled out
    if (empty($first_name) || empty($last_name) || empty($email) || empty($password) || empty($confirm_password)) {
      echo 'Please fill out all fields.';
    }
    // check if the email address is valid
    else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      echo 'Please enter a valid email address.';
    }
    // check if the password and confirm password fields match
    else if ($password !== $confirm_password) {
      echo 'Password and confirm password fields must match.';
    }
    // if all fields are valid, display a success message
    else {
      echo 'Registration successful and Thanks.';
    }
  }
?>